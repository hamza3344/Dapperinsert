﻿using Dapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DapperFramework
{
    public partial class Form1 : Form
    {
        string coonection = "Data Source=DESKTOP-R94LU0S\\SQLEXPRESS;Initial Catalog=formsimple;Integrated Security=True;";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        private void btninsert_Click(object sender, EventArgs e)
        {
            using(SqlConnection coonect=new SqlConnection(coonection))
            {
                coonect.Open();
                coonect.Execute($"INSERT INTO mytable (name,location,mark) VALUES('{txtname.Text}','{txtlocation.Text}','{txtmark.Text}')");
                coonect.Close();
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            
        }
    }
}
